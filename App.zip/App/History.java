package com.example.adebola.sherlockholmes;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class History extends AppCompatActivity {

    @Override
    //Shows History of the events that had occured
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

    }
     //Display history of the events
     public void displayHistory(){

     }

}
